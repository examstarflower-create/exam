//! # Pager with Eager Paging Policy
//!
//! The [`EagerPager`] is a concrete implementation of the [`Pager`] trait used
//! in Project 2 to manage memory mapping behavior during `mmap` system calls.
//! As its name implies, it follows an **eager allocation strategy**: physical
//! pages are allocated and mapped into the page table **immediately** at the
//! time of `mmap`, regardless of whether they are subsequently accessed.
//!
//! This approach ensures that all virtual pages in the mapped region are backed
//! by initialized physical memory at the time of mapping. These pages are
//! typically zero-filled and mapped with the requested permissions (e.g., read,
//! write, execute). This simplifies the memory model and avoids page faults
//! after mapping, making [`EagerPager`] a useful baseline for implementing
//! memory management in early-stage systems like KeOS.
//!
//! The paging interface is defined by the [`Pager`] trait, which abstracts the
//! core functionality for virtual memory: allocation (`mmap`), deallocation
//! (`munmap`), access resolution (`get_user_page`), and permission checking
//! (`access_ok`).
//!
//! In later stages of KeOS (Project 3), you will implement demand paging using
//! `LazyPager`, which defers physical memory allocation until the first
//! access (e.g., page fault). That approach provides a more efficient
//! and realistic memory model used by modern operating systems.
//!
//! ## Memory Loading
//!
//! The eager pager supports both anonymous and file-backed memory mappings.
//! **Anonymous mappings** in eager paging are typically backed by
//! zero-initialized memory. On the other side, when mapping a **file-backed
//! page**, the [`RegularFile::mmap`] method must be used to register the
//! mapping. In Project 5, you will extend this method with the **page cache**,
//! a core mechanism that allows shared, read-consistent access to file data
//! across processes. Although [`EagerPager`] currently does not utilize the
//! page cache, the [`RegularFile`] interface and paging trait are designed to
//! accommodate it cleanly for future extensions.
//!
//! Note that, KeOS does not provide write-back behavior for the file-backed
//! pages.
//!
//! ## Implementation Requirements
//! You need to implement the followings:
//! - [`EagerPager::mmap`]
//! - [`EagerPager::munmap`]
//! - [`EagerPager::get_user_page`]
//! - [`EagerPager::access_ok`]
//!
//! By implementing the eager pager, your kernel now have sufficient
//! functionalities to load user program in the next [`section`].
//!
//! [`section`]: crate::loader
use crate::{page_table::PageTable, pager::Pager};
use alloc::collections::btree_map::BTreeMap;
use keos::{
    KernelError,
    addressing::Va,
    fs::RegularFile,
    mm::{PageRef, page_table::Permission},
};

/// Represent a mapping of contiguous memory.
pub struct Mapping {
    /// Size of the area.
    mapping_size: usize,
    /// Permission of the area.
    perm: Permission,
}

/// [`EagerPager`] is a struct that implements the [`Pager`] trait.
/// It represents a pager strategy that is responsible for eager memory paging.
pub struct EagerPager {
    mappings: BTreeMap<Va, Mapping>,
}

impl Pager for EagerPager {
    /// Creates a new instance of [`EagerPager`].
    ///
    /// This constructor initializes an empty [`EagerPager`] struct.
    fn new() -> Self {
        Self {
            mappings: BTreeMap::new(),
        }
    }

    /// Memory map function (`mmap`) for eager paging.
    ///
    /// This function maps the given memory region into page table.
    /// Returns an address for the mapped area.
    fn mmap(
        &mut self,
        page_table: &mut PageTable,
        addr: Va,
        size: usize,
        prot: Permission,
        file: Option<&RegularFile>,
        offset: usize,
    ) -> Result<usize, KernelError> {
        if addr.into_usize() == 0 || (addr.into_usize() & 0xfff) != 0 || size == 0 {
            return Err(KernelError::InvalidArgument);
        }
        if !prot.contains(Permission::READ) {
            return Err(KernelError::InvalidArgument);
        }
        let mapping_size = size
            .checked_add(0xfff)
            .ok_or(KernelError::InvalidArgument)?
            & !0xfff;

        let start = addr.into_usize();
        let end = start
            .checked_add(mapping_size)
            .ok_or(KernelError::InvalidArgument)?;

        let start_idx = crate::page_table::PtIndices::from_va(addr)
            .map_err(|_| KernelError::InvalidArgument)?
            .pml4ei;
        let last_va = Va::new(end - 0x1000).ok_or(KernelError::InvalidArgument)?;
        let end_idx = crate::page_table::PtIndices::from_va(last_va)
            .map_err(|_| KernelError::InvalidArgument)?
            .pml4ei;

        if start_idx >= keos::mm::page_table::PageTableRoot::KBASE
            || end_idx >= keos::mm::page_table::PageTableRoot::KBASE
        {
            return Err(KernelError::InvalidArgument);
        }

        if let Some((base, mapping)) = self.mappings.range(..=addr).next_back() {
            let base = base.into_usize();
            let mend = base
                .checked_add(mapping.mapping_size)
                .ok_or(KernelError::InvalidArgument)?;
            if start < mend {
                return Err(KernelError::InvalidArgument);
            }
        }

        if let Some((base, _)) = self.mappings.range(addr..).next() {
            if base.into_usize() < end {
                return Err(KernelError::InvalidArgument);
            }
        }

        let mut mapped = 0usize;

        for i in 0..(mapping_size / 0x1000) {
            let va = Va::new(start + i * 0x1000).ok_or(KernelError::InvalidArgument)?;
            let mut page = keos::mm::Page::new();

            {
                let buf = page.inner_mut();
                buf.fill(0);
                if let Some(file) = file {
                    let file_off = offset
                        .checked_add(i * 0x1000)
                        .ok_or(KernelError::InvalidArgument)?;
                    let _ = file.read(file_off, buf)?;
                }
            }

            if page_table.map(va, page, prot).is_err() {
                for j in 0..mapped {
                    let rva = Va::new(start + j * 0x1000).ok_or(KernelError::InvalidArgument)?;
                    let _ = page_table.unmap(rva);
                }
                return Err(KernelError::InvalidArgument);
            }
            mapped += 1;
        }

        self.mappings.insert(
            addr,
            Mapping {
                mapping_size,
                perm: prot,
            },
        );

        Ok(addr.into_usize())
    }

    /// Memory unmap function (`munmap`) for eager paging.
    ///
    /// This function would unmap a previously mapped memory region, releasing
    /// any associated resources.
    fn munmap(&mut self, page_table: &mut PageTable, addr: Va) -> Result<usize, KernelError> {
        let mapping = self
            .mappings
            .remove(&addr)
            .ok_or(KernelError::InvalidArgument)?;

        for i in 0..(mapping.mapping_size / 0x1000) {
            let va = Va::new(addr.into_usize() + i * 0x1000).ok_or(KernelError::InvalidArgument)?;
            page_table
                .unmap(va)
                .map_err(|_| KernelError::InvalidArgument)?;
        }

        Ok(0)
    }

    /// Find a mapped page at the given virtual address.
    ///
    /// This function searches for a memory page mapped at `addr` and, if found,
    /// returns a tuple of [`PageRef`] to the page and its corresponding
    /// [`Permission`] flags.
    fn get_user_page(
        &mut self,
        page_table: &mut PageTable,
        addr: Va,
    ) -> Option<(PageRef<'_>, Permission)> {
        // HINT: use `PageRef::from_pa`
        let page_va = Va::new(addr.into_usize() & !0xfff)?;
        let pte = page_table.walk(page_va).ok()?;

        let mut perm = Permission::READ;
        let flags = pte.flags();

        if flags.contains(keos::mm::page_table::PteFlags::RW) {
            perm |= Permission::WRITE;
        }
        if flags.contains(keos::mm::page_table::PteFlags::US) {
            perm |= Permission::USER;
        }
        if !flags.contains(keos::mm::page_table::PteFlags::XD) {
            perm |= Permission::EXECUTABLE;
        }

        Some((unsafe { PageRef::from_pa(pte.pa()?) }, perm))
    }

    /// Checks whether access to the given virtual address is permitted.
    ///
    /// This function verifies that a virtual address `va` is part of a valid
    /// memory mapping and that the requested access type (read or write) is
    /// allowed by the page's protection flags.
    fn access_ok(&self, va: Va, is_write: bool) -> bool {
        let page_va = match Va::new(va.into_usize() & !0xfff) {
            Some(va) => va,
            None => return false,
        };

        let Some((base, mapping)) = self.mappings.range(..=page_va).next_back() else {
            return false;
        };

        let start = base.into_usize();
        let end = match start.checked_add(mapping.mapping_size) {
            Some(end) => end,
            None => return false,
        };
        let cur = page_va.into_usize();

        if !(start <= cur && cur < end) {
            return false;
        }

        if is_write {
            mapping.perm.contains(Permission::WRITE)
        } else {
            mapping.perm.contains(Permission::READ)
        }
    }
}
